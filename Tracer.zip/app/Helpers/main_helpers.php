<?php

function get_data_registrasi($nim)
{
    $db = \Config\Database::connect('accext_tracer');
    $query = $db->table('ref_registrasi')
            ->where('nim', $nim)
            ->get();
    $results = $query->getUnbufferedRow();
    return $results;
}

function check_status_activation($activation_code)
{
    $db = \Config\Database::connect('accext_tracer');
    $query = $db->table('ref_registrasi')
            ->where('activation', $activation_code)
            ->get();
    $results = $query->getUnbufferedRow();
    return $results;
}

function check_permission_user()
{
    $db = \Config\Database::connect('accext_tracer');
    $query = $db->table('fr_registrasi')
            ->where('nim', Session()->get('C_NPM'))
            ->get();
    $results = $query->getUnbufferedRow();
    return $results;
}
?>