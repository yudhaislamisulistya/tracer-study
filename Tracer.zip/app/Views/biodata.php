<?php

?>
<?= view('layouts/header.php') ?>


<div class="d-flex flex-column-fluid mt-5">
    <div class="container">
        <div class="card card-custom gutter-b">
            <div class="card-header">
                <h3 class="card-title">
                    Biodata Alumni
                </h3>
            </div>
            <!--begin::Form-->
            <div class="card-body">
                <form class="form" id="kt_form">
                    <div class="form-group">
                        <div class="alert alert-light-primary d-none mb-15" role="alert" id="kt_form_msg">
                            <div class="alert-icon">
                                <i class="la la-warning"></i>
                            </div>
                            <div class="alert-text font-weight-bold">
                            Silahkan masukkan informasi untuk mengaktifkan Akun ALUMNI FIKOM UMI.
                            </div>
                            <div class="alert-close">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span><i class="ki ki-close "></i></span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Nama Lengkap *</label>
                        <div class="col-md-10">
                            <div class="input-group">
                                <input type="text" class="form-control" name="nama_lengkap" placeholder="Nama Lengkap"
                                    id="nama_lengkap" value="<?= get_data_registrasi(Session()->get('C_NPM'))->nama ?>" readonly/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Jenis Kelamin *</label>
                        <div class="col-md-10">
                            <div class="input-group">
                                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                                    <option value="L">Laki-Laki</option>
                                    <option value="P">Perempuan</option>
                                </select>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Tempat Lahir *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" class="form-control" name="tempat_lahir" placeholder="Tempat Lahir"
                                    id="tempat_lahir"/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <label class="col-form-label col-md-2">Tanggal Lahir *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="date" class="form-control" name="tanggal_lahir " placeholder="Tanggal Lahir"
                                    id="tanggal_lahir   "/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">NIM *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" class="form-control" name="nim" placeholder="NIM"
                                    id="nim"/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <label class="col-form-label col-md-2">Program Studi *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                            <select name="program_studi" id="program_studi" class="form-control">
                                    <option value="L">Teknik Informatika</option>
                                    <option value="P">Sistem Informasi</option>
                                </select>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Tahun Masuk *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" class="form-control" name="tahun_masuk" placeholder="Tahun Masuk"
                                    id="tahun_masuk"/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <label class="col-form-label col-md-2">Tahun Keluar *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" class="form-control" name="tahun_keluar" placeholder="Tahun Keluar"
                                    id="tahun_keluar"/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Alamat *</label>
                        <div class="col-md-10">
                            <div class="input-group">
                                <input type="text" class="form-control" name="alamat" placeholder="Alamat Lengkap"
                                    id="alamat"/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-md-1">Negara *</label>
                        <div class="col-md-3">
                            <div class="input-group">
                                <select name="negara" id="negara" class="form-control">
                                    <option value="L">Indonesia</option>
                                </select>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <label class="col-form-label col-md-1">Provinsi *</label>
                        <div class="col-md-3">
                            <div class="input-group">
                                <select name="provinsi" id="provinsi" class="form-control">
                                        <option value="L">Sulawesi Selatan</option>
                                    </select>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <label class="col-form-label col-md-1">Kabupaten *</label>
                        <div class="col-md-3">
                            <div class="input-group">
                                <select name="kabupaten" id="kabupaten" class="form-control">
                                        <option value="L">Tojo Una-Una</option>
                                    </select>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Email *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" class="form-control" name="email" placeholder="Email"
                                    id="email" value="<?= get_data_registrasi(Session()->get('C_NPM'))->email ?>"/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <label class="col-form-label col-md-2">Nohp/Whatsapp *</label>
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" class="form-control" name="nohp" placeholder="Whatsapp"
                                    id="nohp" value="<?= get_data_registrasi(Session()->get('C_NPM'))->nomor_handphone ?>"/>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <i class="la la-calendar-check-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-10 ml-lg-auto">
                            <button type="submit" class="btn btn-primary mr-2">Proses</button>
                            <button type="reset" class="btn btn-light-primary">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= view('layouts/footer.php') ?>